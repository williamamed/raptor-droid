package cu.raptor.mobile.plugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.ContactsContract.CommonDataKinds;
import android.util.Base64;

import cu.raptor.mobile.Controller;
import cu.raptor.mobile.Event;
import cu.raptor.mobile.LogM;

/**
 * Example
 */
public class CoreEvents extends Controller {
    private String mCurrentPhotoPath;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_IMAGE_CAPTURE_THUMBNAIL = 2;
    private int dinamycRequest;

    @Event("getProperty")
    public String getDataProperty(Object data) {
        
        try {
            JSONObject obj=(JSONObject)data;
            //return "jjj";
			return (String)Class.forName(obj.getString("class")).getDeclaredField(obj.getString("property")).get(null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
            e.printStackTrace();
            return "no";
		}
    }

    @Event("droid:set.proxy")
    public void proxy(Object data) {
        JSONObject prox=(JSONObject)data;
        try {
            
            activity.currentProxy.add(prox.getString("username"));
            activity.currentProxy.add(prox.getString("password"));
            if(prox.getString("checkurl").startsWith("http"))
                activity.getWebView().loadUrl(prox.getString("checkurl"));
            else
                activity.loadLocalPage(prox.getString("checkurl").replace("file:///android_asset/www/", ""));
		} catch (JSONException e) {
            // TODO Auto-generated catch block
            LogM.e( "Error username "+e.getMessage());
			e.printStackTrace();
		}
       
    }

    @Event("droid:photo")
    public void picture(Object data) {

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {

            if (((String) data).equals("thumbnail")) {
                activity.startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE_THUMBNAIL);
            } else {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    
                }
                // Continue only if the File was successfully created
                
                if (photoFile != null) {
                    /**Uri photoURI = FileProvider.getUriForFile(this,
                    "com.dinobyte.hola.fileprovider",
                    photoFile);*/
                    
                    Uri photoURI = Uri.fromFile(photoFile);
                    
                    try{
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    activity.startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    }catch(Exception e){
                        LogM.e( "Error 2"+e.getMessage());
                    }
                }
            }

        }
    }

    @Event("mobile:activityResult")
    public void activityResult(Object requestCode, Object resultCode, Object data) {
        
        if ((Integer) requestCode == REQUEST_IMAGE_CAPTURE && (Integer) resultCode == activity.RESULT_OK) {
            LogM.e("Test"+((Integer)resultCode)+"-"+activity.RESULT_OK+"-"+(Integer)requestCode+mCurrentPhotoPath);
            activity.send("droid:photo.result", mCurrentPhotoPath);
        }

        if ((Integer) requestCode == REQUEST_IMAGE_CAPTURE_THUMBNAIL && (Integer) resultCode == activity.RESULT_OK) {

            Bundle extras = ((Intent) data).getExtras();
            Bitmap bitmap = (Bitmap) extras.get("data");
            // Convert bitmap to Base64 encoded image for web
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);

            byte[] byteArray = byteArrayOutputStream.toByteArray();
            String imgageBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT);

            String result = "data:image/png;base64," + imgageBase64;
            result = result.replaceAll("\n", "");
            // LogM.e("Test"+((Integer)resultCode)+"-"+activity.RESULT_OK+"-"+(Integer)requestCode+result);
            activity.send("droid:photo.result", result);
        }
        
        if(dinamycRequest==(Integer) requestCode){
            JSONObject resultObj=new JSONObject();
            try {
                resultObj.put("uri", ((Intent) data).getData().toString());
                
                //String[] projection=new String[]{CommonDataKinds.Phone.NUMBER};
                /**Cursor cursor=activity.getContentResolver().query(((Intent) data).getData(), null, null, null,null);
                if(cursor!=null && cursor.moveToFirst()){
                    
                    String number=cursor.getString(cursor.getColumnIndex(CommonDataKinds.Phone.NUMBER));
                    //String name=cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    resultObj.put("contact",number);
                    
                }
                Bundle extras = ((Intent) data).getExtras();
                Bitmap bitmap = (Bitmap) extras.get("data");
                if(bitmap!=null){
                    // Convert bitmap to Base64 encoded image for web
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    
                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                    String imgageBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT);

                    String result = "data:image/png;base64," + imgageBase64;
                    result = result.replaceAll("\n", "");
                    resultObj.put("thumbnail",result);
                }*/
                // LogM.e("Test"+((Integer)resultCode)+"-"+activity.RESULT_OK+"-"+(Integer)requestCode+result);
                
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            activity.send("droid:activity.result", resultObj.toString());
            //content://contacts/people/
            /**Uri u= ((Intent) data).getData();
            Cursor cursor=activity.managedQuery(u, null, null, null, null);
            cursor.moveToFirst();
            String[] columns=cursor.getColumnNames();
            String dataResult="";
            for (int i = 0; i < columns.length; i++) {
                dataResult+=cursor.getString(cursor.getColumnIndexOrThrow(columns[i]))+", ";
            }
            LogM.e( dataResult);*/
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file://" + image.getAbsolutePath();
        return image;
    }

    @Event("ejemplo1")
    public void miMetodo(Object data) {
        try {
            JSONObject data2 = (JSONObject) data;
            LogM.e( "Probando funcion ejemplo 1" + data2.getString("somos"));
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Event("initTick")
    public void initTick(Object data) {
        Tiempo cuento = new Tiempo(6000, 1000);
        cuento.start();
    }

    @Event("droid:openurl")
    public void openurl(Object data) {
        LogM.e( "hola openurl");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse((String) data));
        activity.startActivity(intent);
    }

    @Event("droid:loadurl")
    public void internalopenurl(Object data) {
        activity.loadLocalPage((String)data);
    }

    @Event("droid:intent")
    public void startIntent(Object data) {
        LogM.e( "abriendo intent ");
        
        
        try {
            JSONObject config = (JSONObject) data;
            Intent intent = null;
            if(config.has("uri")){
                intent = new Intent(config.getString("action"),Uri.parse(config.getString("uri")));
            }else{
                intent = new Intent(config.getString("action"));
            }
            
            if(config.has("extras")){
                JSONArray extras=config.getJSONArray("extras");
                for (int i = 0; i < extras.length(); i++) {
                    intent.putExtra(extras.getJSONObject(i).getString("name"), extras.getJSONObject(i).getString("value"));
                }
            }
            
            if(config.has("type")){
                intent.setType(config.getString("type"));
            }

            if(config.has("result")){
                dinamycRequest=config.getInt("result");
                activity.startActivityForResult(intent, config.getInt("result"));
            }else{
                dinamycRequest=-1;
                activity.startActivity(intent);
            }
            
            
            
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            LogM.e( e.getMessage());
            e.printStackTrace();
        }
        
        
    }

    @Event("droid:notification")
    public void notification(Object data) {
        JSONObject conf=(JSONObject)data;

        NotificationManager nm = (NotificationManager) activity.getSystemService(activity.NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel("default", "default",
                    NotificationManager.IMPORTANCE_DEFAULT);
            mChannel.setDescription("Hola 1");
            mChannel.canShowBadge();
            mChannel.setShowBadge(true);
            nm.createNotificationChannel(mChannel);
            nb = new Notification.Builder(activity, "default");

        } else
            nb = new Notification.Builder(activity);

        try {
            String icon=activity.config.getString("icon").split("/")[0];
            Notification notification = nb
                .setContentTitle(conf.getString("title"))
                .setContentText(conf.getString("text"))
                .setNumber(5)
                .setAutoCancel(true)
                .setSmallIcon(
                            activity.getResources().getIdentifier(icon, "mipmap", activity.getPackageName()))
                .build();

            nm.notify(101, notification);
        } catch (Exception e) {
            LogM.e( e.getMessage());
        }
        LogM.e( "show notification");
    }

    public class Tiempo extends CountDownTimer {

        public Tiempo(long mil, long count) {
            super(mil, count);
        }

        @Override
        public void onFinish() {
            activity.send("droid:tick", "Bienvenido a Raptor droid !!");
        }

        @Override
        public void onTick(long millisUntilFinish) {
            activity.send("droid:tick", "" + millisUntilFinish / 1000);
        }
    }
}