package cu.raptor.mobile;



import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;


/**
 * Controller
 */
public class Controller {
    protected MobileActivity activity;

    public void setActivity(MobileActivity activity) {
        this.activity=activity;
    }
    
    @Event("mobile:hola")
    public void name(Object data) {
        LogM.e("Probando funcion controladora");
    }

    @Event("droid:playsound")
    public void play(Object data) {
        LogM.e("Audio play");
        try {
            MediaPlayer m= new MediaPlayer();
            
    
            AssetFileDescriptor descriptor = activity.getAssets().openFd("www/"+(String)data);
            m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
            descriptor.close();
    
            m.prepare();
            m.setVolume(1f, 1f);
            //m.setLooping(true);
            m.start();
        } catch (Exception e) {
            activity.send("mobile:error",e.getMessage());
            e.printStackTrace();
        }
    }
}