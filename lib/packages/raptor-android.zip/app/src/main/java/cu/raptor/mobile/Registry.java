package cu.raptor.mobile;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;





public class Registry{
    
    private Map<String, List<ControllerEvent>> controllers;
    
    protected MobileActivity activity;
    
    public Registry(MobileActivity activity){
        
        controllers = new HashMap<String,List<ControllerEvent>>();
        this.activity=activity;
    }
    
    public void add(Controller controller){
        //controller.add(controller);
        controller.setActivity(activity);
        
        this.processAnnotation(controller);
    }

    private void processAnnotation(Controller controller) {
        //Class<?> contr=Class.forName(controller.getClass().getName());
        Object conts=controller;
        Method[] methods=conts.getClass().getMethods();
        
        for (Method method : methods) {
            if(method.isAnnotationPresent(Event.class)){
                Event e=method.getAnnotation(Event.class);
                if(controllers.get(e.value())==null){
                    List<ControllerEvent> contrList=new ArrayList<ControllerEvent>();
                    contrList.add(new ControllerEvent(controller.getClass().getName()+"/"+method.getName(), controller));
                    controllers.put(e.value(),contrList);
                    
                }else
                    controllers.get(e.value()).add(new ControllerEvent(controller.getClass().getName()+"/"+method.getName(), controller));
                
                
            }
        }
    }

    public Object executeAction(String name,Object... data) {
        if(controllers.get(name)!=null){
            List<ControllerEvent> suscribe=controllers.get(name);
            for (int i = 0; i < suscribe.size(); i++) {
                String[] command=suscribe.get(i).getName().split("/");
                Controller contr=suscribe.get(i).getController();
                try {
                    Class params[] = new Class[data.length];
                    for (int j = 0; j < data.length; j++) {
                        params[j]=Object.class;
                    }
                    return contr.getClass().getMethod(command[1],params).invoke(contr,data);
                    
                    //contr.getClass().getMethod(command[1],data.getClass()).invoke(contr,data);
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalArgumentException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    // TODO Auto-generated catch block
                    LogM.e(e.getMessage());
                    e.printStackTrace();
                } catch (SecurityException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            
        }
        return null;
    }

    /**
     * 
     */
    public class ControllerEvent {
        private String name;
        private Controller controller;

        public ControllerEvent(String name,Controller controller){
            this.name=name;
            this.controller=controller;
        }

        /**
         * @return the controller
         */
        public Controller getController() {
            return controller;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        
        
    }

}