package cu.raptor.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebStorage.QuotaUpdater;
import android.widget.Toast;
import cu.raptor.mobile.plugin.App;



public class MobileActivity extends Activity {
    private WebView wv;
    private SharedPreferences pref;
    private Registry reg;
    final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
    public List<String> currentProxy;
    public JSONObject config;
    private static MobileActivity instance;

    public static Context geContext() {
        return instance;
    }

    public void setRegistry(Registry r) {
        reg=r;
    }

    public WebView getWebView() {
        return wv;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        instance=this;
        super.onCreate(savedInstanceState);
        LogM.e( getPackageName());
        
        setContentView(getResources().getIdentifier("activity_main", "layout",getPackageName()));
        currentProxy=new ArrayList<String>();

        pref = getSharedPreferences("raptor-mobile", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("rmobile:test","Some text preference");
        editor.commit();

        wv = (WebView) findViewById(getResources().getIdentifier("webview", "id",getPackageName()));
        wv.setVisibility(View.VISIBLE);
        checkFullPermission();
        
    }
    
    public String readAsset(String path){
       
        try {
            
            
            InputStream is=getAssets().open(path);
            int size=is.available();
            byte[] buffer=new byte[size];
            is.read(buffer);
            is.close();
            return new String(buffer,"UTF-8");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "";
    }

    public void loadLocalPage(String url) {
        loadLocalPage(url, new JSONObject());
    }

    public void loadLocalPage(String url,JSONObject data) {
        String core=readAsset("www/__base.html");
        String main=url;
        String toPass="<script>$m.initData="+data.toString()+"</script>";
        if(url.length()==0){
            main="index.html";
            if(config.has("main")){
				try {
					main=config.getString("main");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
                }
            }
            
        }
        String target=readAsset("www/"+main);
        wv.loadDataWithBaseURL("file:///android_asset/www/"+main, core+toPass+target, "text/html", "UTF-8", null);
    }

    public void loadJavascript(String path){
        
        String lib2="(function(){"+
        "var parent = document.getElementsByTagName('head').item(0);"+
        "var script = document.createElement('script');"+
        
        "script.src='"+path+"';"+
        "parent.appendChild(script);"+
        "})()";
        //LogM.e( lib2+" core library");
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            wv.evaluateJavascript(lib2, null);
            
        } else {
            wv.loadUrl("javascript:"+lib2);
            
        }
    }


    public void send(String name,String data){
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            wv.evaluateJavascript("RMobile.trigger('"+name+"', ['"+data+"']);", null);
            
        } else {
            wv.loadUrl("javascript:RMobile.trigger('"+name+"', ['"+data+"']);");
            
        }
    }
    
    private void PermissionsChecked() {
        
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setAppCacheEnabled(true);
        wv.getSettings().setAllowUniversalAccessFromFileURLs(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
        wv.setSoundEffectsEnabled(true);
        wv.getSettings().setAllowFileAccessFromFileURLs(true);
        wv.getSettings().setDatabaseEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.KITKAT){
            wv.getSettings().setDatabasePath("/data/data"+wv.getContext().getPackageName()+"/databases/");
        }
        
        wv.addJavascriptInterface(new App(this), "Android");
        
        wv.setWebChromeClient(new WebChromeClient() {
            

            @Override
            public void onExceededDatabaseQuota(String url, String databaseIdentifier, long quota,
                    long estimatedDatabaseSize, long totalQuota, QuotaUpdater quotaUpdater) {
                quotaUpdater.updateQuota(quota + (5*1024*1024));
            }


            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                
                LogM.e( consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber() + " of "
                        + consoleMessage.sourceId());
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                    /** wv.evaluateJavascript("setDebugInfo('"+consoleMessage.message() + " -- From line "
                     + consoleMessage.lineNumber() + " of "
                     + consoleMessage.sourceId()+"');", null);*/

                } else {
                    /** wv.loadUrl("javascript:setDebugInfo('"+consoleMessage.message() + " -- From line "
                     + consoleMessage.lineNumber() + " of "
                     + consoleMessage.sourceId()+"');");*/
                }
                return super.onConsoleMessage(consoleMessage);
            }
        });
        
        wv.setWebViewClient(new MobileWebView(this));
        
        wv.setDownloadListener(new DownloadListener(){
        
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimetype);
                String cookies=CookieManager.getInstance().getCookie(url);
                request.addRequestHeader("cookie", cookies);
                request.addRequestHeader("User-Agent", userAgent);
                request.setDescription("Descargando...");
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
                DownloadManager dm=(DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
                Toast.makeText(getApplicationContext(),"Descargando...", Toast.LENGTH_LONG).show();
            }
        });

        try {
			config=new JSONObject(readAsset("www/config.json"));
		} catch (JSONException e) {
            // TODO Auto-generated catch block
            LogM.e(e.getMessage());
			e.printStackTrace();
		}

        loadLocalPage("");
    }

    public void initWebApp(String url) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            wv.evaluateJavascript("loadPage('"+url+"');", null);
            
        } else {
            wv.loadUrl("javascript:loadPage('"+url+"');");
            
        }
    }

    private void checkFullPermission() {
        List<String> permissionsNeeded = new ArrayList<String>();

        List<String> permissionsList = new ArrayList<String>();
        //LogM.e(Manifest.permission.ACCESS_NETWORK_STATE);
        /**if (!addPermission(permissionsList, Manifest.permission.INTERNET))
            permissionsNeeded.add("INTERNET");
        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("WRITE_EXTERNAL_STORAGE");*/
        String[] perm;
        try {
            perm=getPackageManager()
                    .getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS)
                    .requestedPermissions;
        } catch (PackageManager.NameNotFoundException e) {
            throw new RuntimeException ("This should have never happened.", e);
        }
        if (perm.length > 0) {
            
            // Need Rationale
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(perm,
                        REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                return;
            }
            
        }
        
        /**permissionsList=getPackageManager()
                .getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS)
                .requestedPermissions;

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                // Need Rationale
                String message = "You need to grant access to " + permissionsNeeded.get(0);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(permissionsList.toArray(new String[permissionsList.size()]),
                            REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                }
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]),
                        REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
            }
            return;
        }*/
        PermissionsChecked();
        //
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                // Check for Rationale Option
                if (!shouldShowRequestPermissionRationale(permission))
                    return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:
            {
                Map<String, Integer> perms = new HashMap<String, Integer>();
                
                String[] perm;
                try {
                    perm=getPackageManager()
                            .getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS)
                            .requestedPermissions;
                } catch (PackageManager.NameNotFoundException e) {
                    throw new RuntimeException ("This should have never happened.", e);
                }
                
                for(int i=0;i<perm.length;i++){
                    perms.put(perm[i], PackageManager.PERMISSION_GRANTED);
                }
                
                // Initial
                // perms.put(Manifest.permission.ACCESS_FINE_LOCATION, PackageManager.PERMISSION_GRANTED);
                // perms.put(Manifest.permission.ACCESS_NETWORK_STATE, PackageManager.PERMISSION_GRANTED);
                //perms.put(Manifest.permission.INTERNET, PackageManager.PERMISSION_GRANTED);
                // perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
                //perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                // Fill with results
                int count=0;
                for (int i = 0; i < permissions.length; i++){
                    if(grantResults[i]==PackageManager.PERMISSION_GRANTED)
                        count++;
                }
                if(count==permissions.length)
                    PermissionsChecked();
                else
                    Toast.makeText(MobileActivity.this, "Some Permission is Denied", Toast.LENGTH_SHORT)
                            .show();
                //    perms.put(permissions[i], grantResults[i]);
                // Check for ACCESS_FINE_LOCATION
                /**if (perms.get(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED 
                && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    // All Permissions Granted
                    PermissionsChecked();
                } else {
                    // Permission Denied
                    Toast.makeText(MainActivity.this, "Some Permission is Denied", Toast.LENGTH_SHORT)
                            .show();
                }*/
            }
            break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        reg.executeAction("mobile:activityResult", Integer.valueOf(requestCode),Integer.valueOf(resultCode),data);
    }

}
