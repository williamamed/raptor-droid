package cu.raptor.mobile;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.content.SharedPreferences;


public class WebInterface{
    protected MobileActivity activity;

    /** Instantiate the interface and set the context */
    public WebInterface(Context c) {
        activity = ((MobileActivity) c);
    }
    
    @JavascriptInterface
    public void toast(final String texto) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, texto, Toast.LENGTH_SHORT)
                        .show();
            }
        });

    }
    
    @JavascriptInterface
    public void savePref(String str,String value) {
        SharedPreferences preferencias = activity.getSharedPreferences("raptor-mobile", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putString(str,value);
        LogM.e(" Salvando preferencia ");
        editor.commit();
    }
    
    @JavascriptInterface
    public String getPref(String str) {
        SharedPreferences preferencias = activity.getSharedPreferences("raptor-mobile", Context.MODE_PRIVATE);
        return preferencias.getString(str,"");
    }
    
}