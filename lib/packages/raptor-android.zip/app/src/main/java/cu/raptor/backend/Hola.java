package cu.raptor.backend;

import cu.raptor.mobile.Controller;
import cu.raptor.mobile.Event;

/**
 * Hola
 */
public class Hola extends Controller {
    

    @Event("Hola")
    public void firstEvent(Object data) {

    }

}