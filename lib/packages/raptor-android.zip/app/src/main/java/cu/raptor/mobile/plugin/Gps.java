package cu.raptor.mobile.plugin;

import java.text.DecimalFormat;
import java.util.Iterator;

import android.annotation.SuppressLint;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import cu.raptor.mobile.Controller;
import cu.raptor.mobile.Event;
import cu.raptor.mobile.LogM;

/**
 * Gps
 */
public class Gps extends Controller{

    static LocationManager lm;
    static MiLocationListener mlistener;
    public static String lat, lon, loc, carro;
    int nsat, msat, alt, tiempo, error;
    double vel;
    private GpsStatus mStatus;

    @Event("mobile:gps.init")
    public void initGps(Object data) {
        lm = (LocationManager) activity.getSystemService(activity.LOCATION_SERVICE);
        mlistener = new MiLocationListener();
        lm.addGpsStatusListener(mlistener);
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000,1, mlistener);
    }

    public class MiLocationListener implements LocationListener, GpsStatus.Listener {

        @Override
        public void onLocationChanged(Location location) {
            DecimalFormat f = new DecimalFormat("######.########");
            
            lat = f.format(location.getLatitude()).replace(",", ".");
            lon = f.format(location.getLongitude()).replace(",", ".");
            alt = (int) location.getAltitude();
            //Registrar();
 
            error = (int) location.getAccuracy();
            int vel_mt = (int) location.getSpeed();

            vel = (((double) vel_mt * 60) * 60) / 1000;
            loc = "{lat: " + lat + ", lon: " + lon+"}";
            
            // Datos del GPS
            //String tsat = (String) (loc + "\n" + getResources().getString(R.string.alt) + " " + alt + " m" + "\n" + "Vehículo: " + carro);

            //nsatelites.setText(tsat);
            activity.send("mobile:gps.location", loc);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            //LogM.e( "Gps provider status "+status);
        }

        @Override
        public void onProviderEnabled(String provider) {
            LogM.e( "Gps provider enabled ");
        }

        @Override
        public void onProviderDisabled(String provider) {
            LogM.e( "Gps provider disabled ");
        }

        @SuppressLint("MissingPermission")
		@Override
		public void onGpsStatusChanged(int event) {
            
			mStatus = lm.getGpsStatus(mStatus);
            
            switch (event) {
                case GpsStatus.GPS_EVENT_STARTED:

                    activity.send("mobile:gps.status","{status:true}");
                    
                    break;

                case GpsStatus.GPS_EVENT_STOPPED:
                    activity.send("mobile:gps.status","{status:false}");
                    
                    break;

                case GpsStatus.GPS_EVENT_FIRST_FIX:
                    // Do Something with mStatus info
                    break;

                case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
                    // Do Something with mStatus info
                    
                    Iterator<GpsSatellite> satellites = mStatus.getSatellites().iterator();
                    int mSvCount = 0;
                    int mUsedInFixCount = 0;
                    while (satellites.hasNext()) {
                        GpsSatellite satellite = satellites.next();
                        int prn = satellite.getPrn();

                        if (satellite.usedInFix()) {
                            mUsedInFixCount++;
                        }
                        mSvCount++;
                    }
                    activity.send("mobile:gps.status","{status:true,satelliteCount:"+mSvCount+",satelliteUsed:"+mUsedInFixCount+"}");

                    break;
            }
		}

    }
}