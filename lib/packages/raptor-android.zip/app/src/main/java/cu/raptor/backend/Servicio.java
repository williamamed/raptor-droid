package cu.raptor.backend;

import cu.raptor.mobile.Controller;
import cu.raptor.mobile.Event;

/**
 * Servicio
 */
public class Servicio extends Controller {
    

    @Event("Servicio")
    public void firstEvent(Object data) {

    }

}