package cu.raptor.mobile.plugin;


import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import cu.raptor.mobile.AppKernel;
import cu.raptor.mobile.Controller;
import cu.raptor.mobile.LogM;

/**
 * App
 */
public class App extends AppKernel{

    public App(Context c){
        super(c);
        registry.add(new CoreEvents());
        registry.add(new Gps());
        String config="";
        try {
            
            StringBuilder sb=new StringBuilder();
            InputStream is=activity.getAssets().open("www/config.json");
            BufferedReader br=new BufferedReader(new InputStreamReader(is));
            String str;
            while((str=br.readLine())!=null){
                sb.append(str);
            }
            br.close();
            config=sb.toString();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            LogM.e( config);
            LogM.e( e.getMessage());
            e.printStackTrace();
        }

        try {
            JSONObject configObject=new JSONObject(config);
            if(configObject.has("backend")){
                JSONArray backends=configObject.getJSONArray("backend");
                for (int i = 0; i < backends.length(); i++) {
                    Class<?> load=Class.forName("cu.raptor.backend."+backends.getString(i));
                    try {
                        Controller loadNew=(Controller)load.newInstance();
                        registry.add(loadNew);
                        //LogM.e( "adicionado "+backends.getString(i));
					} catch (InstantiationException e) {
                        // TODO Auto-generated catch block
                        LogM.e( e.getMessage());
						e.printStackTrace();
					} catch (IllegalAccessException e) {
                        // TODO Auto-generated catch block
                        LogM.e( e.getMessage());
						e.printStackTrace();
					}
                }
            }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
            e.printStackTrace();
            LogM.e( e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
            e.printStackTrace();
            LogM.e( e.getMessage());
		}
        
    }
}