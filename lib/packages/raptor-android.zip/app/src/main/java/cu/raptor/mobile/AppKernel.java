package cu.raptor.mobile;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.webkit.JavascriptInterface;



public class AppKernel extends WebInterface{
    protected final Registry registry;
    /** Instantiate the interface and set the context */
    public AppKernel(Context c) {
        super(c);
        this.registry=new Registry(activity);
        ((MobileActivity)c).setRegistry(this.registry);
        
    }
    
    @JavascriptInterface
    public String runEventString(final String evento,final String datos) {
        return (String)runEvent(evento, datos);
    }

    @JavascriptInterface
    public Integer runEventInteger(final String evento,final String datos) {
        return (Integer)runEvent(evento, datos);
    }

    @JavascriptInterface
    public Object runEvent(final String evento,final String datos) {
        
        /**activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject data=new JSONObject(datos);
                    registry.executeAction(evento,data);
				} catch (JSONException e) {
                    registry.executeAction(evento,datos);
                    
				}
                
            }
        });*/
        FutureTask<Object> future=new FutureTask<Object>(new Callable<Object>() {

			@Override
			public Object call() throws Exception {
                try {
                    JSONObject data=new JSONObject(datos);
                    return registry.executeAction(evento,data);
				} catch (JSONException e) {
                    return registry.executeAction(evento,datos);
                    
				}
				
			}
        });
        activity.runOnUiThread(future);
        try {
			return (String)future.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
        }
        return null;
    }
    
    
    
}