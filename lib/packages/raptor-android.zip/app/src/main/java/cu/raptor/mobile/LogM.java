package cu.raptor.mobile;

import android.util.Log;

/**
 * LogM
 */
public class LogM {

    public static void e(String text) {
        
        Log.e(MobileActivity.geContext().getPackageName(), text);
        
    }
}