package cu.raptor.mobile;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.http.SslError;

import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * MobileWebView
 */
public class MobileWebView extends WebViewClient{
    private MobileActivity context;
    private int counterAuth;
    
    public MobileWebView(Context context){
        this.context=(MobileActivity)context;
        counterAuth=0;
        
    }

    @Override
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        handler.proceed();
    }

    @Override
    public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
        //implementar alguna logica
        LogM.e( "required auth "+realm+"---"+view.getOriginalUrl());
        
        if(counterAuth<15) {
            //SharedPreferences pref = context.getSharedPreferences("raptor-mobile", Context.MODE_PRIVATE);
            //handler.proceed(pref.getString("proxy.user",""), pref.getString("proxy.pass",""));
            //counterAuth++;
        }
        
        if(context.currentProxy.size()>0){
            String user=context.currentProxy.get(0);
            String pass=context.currentProxy.get(1);
            context.currentProxy.clear();
            handler.proceed(user, pass);
            
        }else{
            handler.cancel();
            JSONObject data=new JSONObject();
            try {
                data.put("realm", realm);
                data.put("checkurl", view.getOriginalUrl());
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            context.loadLocalPage("__proxy.html",data);
        }
            
        //context.send("mobile:proxy","{\"host\":\""+host+"\",\"realm\":\""+realm+"\"}");
        /**if(view.getHttpAuthUsernamePassword(host, realm)[0].length()>0)
            handler.proceed(view.getHttpAuthUsernamePassword(host, realm)[0], view.getHttpAuthUsernamePassword(host, realm)[1]);
        else
            context.send("mobile:proxy","{\"host\":\""+host+"\",\"realm\":\""+realm+"\"}");*/
    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        //LogM.e( "start");
        
        
    }


    @Override
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);

        LogM.e("->>loadurl " + url);
        
    }
    @Override 
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        
        view.loadUrl("about:blank");
        LogM.e("->>fail loadurl " + failingUrl);
        
        //view.loadUrl("file:///android_asset/www/index.html");
    }
    
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        
        LogM.e("shouldOverrideUrlLoading --> "+url);
        return false; 
    }
    
    

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest url) {
        
        LogM.e("shouldOverrideUrlLoading 2 --> "+url);
        return false; 
    }
}