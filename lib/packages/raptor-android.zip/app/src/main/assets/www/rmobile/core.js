
RMobile={
send:function(event,data){
    var toSend=data;
    if(typeof data=="object"){
        toSend=JSON.stringify(toSend);
    }
    if(!data)
        toSend=""
        
    return Android.runEvent(event,toSend);
},
sendGetString:function(event,data){
    var toSend=data;
    if(typeof data=="object"){
        toSend=JSON.stringify(toSend);
    }
    if(!data)
        toSend=""
        
    return Android.runEventString(event,toSend);
},
sendGetInt:function(event,data){
    var toSend=data;
    if(typeof data=="object"){
        toSend=JSON.stringify(toSend);
    }
    if(!data)
        toSend=""
        
    return Android.runEventInteger(event,toSend);
},
on:function(event,func){
    return $(document).on(event,func)
},
trigger:function(name,data){
    return $(document).trigger(name,data)
},
test:function(data){
    console.log(data)
},
loadPage:function(url){
    $m.send('droid:loadurl',url)
}
}

window.__console=window.console;

window.console={
log:function(){
    var message=[]
    for (var i = 0; i < arguments.length; i++) {
        if(typeof arguments[i]!="string")
            message.push(JSON.stringify(arguments[i]))
        else
            message.push(arguments[i])
    }
    window.__console.log(message.join(','))
}
}
window.loadPage4=function(url,index){
$.get(url,function(page){
    $(document).add('*').off();
    var newDoc=document.open('replace')
    newDoc.write(page);
    newDoc.close()
    RMobile.trigger("mobile:ready","El dispositivo esta listo")
})
.fail(function(data,data2){
    console.log("error loading page "+url)
    console.log(data.status)
})

}
$m=RMobile;
$d=RMobile;
$(document).ready(function(){
/**$.get('config.json',function(page){
    var config=JSON.parse(page)
    if(config.main)
        window.loadPage(config.main,true)
    else
        window.loadPage('index.html',true)
})*/
RMobile.trigger("droid:ready","El dispositivo esta listo")
})
$m.on('mobile:proxy',function(e,data){

var proxy=JSON.parse(data)
//$('body').append("<iframe class='' src='proxy.html'>")
/**$m.send('mobile:set.proxy',{
    host:proxy.host,
    realm:proxy.realm,
    username:'william.tamayo',
    password:'pepillo31'
})*/
})