var app = angular.module("myApp", ['ngMaterial']);

app.controller("AppCtrl", function ($scope,$mdDialog) {
    
    $scope.showAlert=function(ev){
        
        $mdDialog.show(
            $mdDialog.alert()
            .parent(document.body)
            .clickOutsideToClose(true)
            .title('Este es un mensaje de alerta')
            .textContent('Puedes especificar un descripción de la problemática planteada')
            .ariaLabel('Alert')
            .ok('Lo tengo!!')
            .targetEvent(ev)
        )
    }
})
