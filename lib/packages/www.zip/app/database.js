
$d.database={
    init:function(){
        db.open({
            server: 'my-app',
            version: 1,
            schema: {
                people: {
                    key: {keyPath: 'id', autoIncrement: true},
                    // Optionally add indexes
                    indexes: {
                        firstName: {},
                        answer: {unique: true}
                    }
                }
            }
        }).then(function (s) {
            $d.database.handler = s;
        });
    }
}

$.database.init()

